const Error = () => {
  return <h1>Error Page</h1>;
};

export default Error;
