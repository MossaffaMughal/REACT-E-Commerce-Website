const Footer = () => {
  return (
    <div className="flex w-full items-center justify-center bg-[#243049] p-4 text-white">
      <h1>All rights reserved</h1>
    </div>
  );
};

export default Footer;
